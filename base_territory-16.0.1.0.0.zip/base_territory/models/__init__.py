# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import res_region, res_district, res_branch, res_territory, res_country
